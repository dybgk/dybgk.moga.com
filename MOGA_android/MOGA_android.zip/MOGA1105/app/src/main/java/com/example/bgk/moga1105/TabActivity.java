package com.example.bgk.moga1105;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tsengvn.typekit.TypekitContextWrapper;

public class TabActivity extends AppCompatActivity {

    private LinearLayout pay;
    private LinearLayout income;
    private LinearLayout report;
    private LinearLayout direct;
    private LinearLayout logout;

    private TextView pay_txt;
    private TextView income_txt;
    private TextView report_txt;
    private TextView direct_txt;
    private TextView logout_txt;

    private LinearLayout toastLayout;
    private TextView toastTV;
    private Toast toast;

    private final int FRAGMENT1 = 1;
    private final int FRAGMENT2 = 2;
    private final int FRAGMENT3 = 3;
    private final int FRAGMENT4 = 4;

    final long FINISH_INTERVAL_TIME = 2000;
    long backPressedTime = 0;

    public String t_id;

    TextView customTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getSupportActionBar().setCustomView(R.layout.custom_title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        customTitle = (TextView)findViewById(R.id.customTitle);
        customTitle.setText(R.string.app_name);

        setContentView(R.layout.custom_tab);

        pay = (LinearLayout) findViewById(R.id.pay);
//        income = (LinearLayout) findViewById(R.id.income);
        report = (LinearLayout) findViewById(R.id.report);
        direct = (LinearLayout) findViewById(R.id.direct);
        logout = (LinearLayout) findViewById(R.id.logout);

        pay_txt = (TextView) findViewById(R.id.pay_txt);
//        income_txt = (TextView) findViewById(R.id.income_txt);
        report_txt = (TextView) findViewById(R.id.report_txt);
        direct_txt = (TextView) findViewById(R.id.direct_txt);
        logout_txt = (TextView) findViewById(R.id.logout_txt);

        Intent from_main = getIntent();
        t_id = from_main.getStringExtra("m_id");

        t_id = "poi";

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callFragment(FRAGMENT1);
            }
        });

//        income.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                callFragment(FRAGMENT2);
//            }
//        });

        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callFragment(FRAGMENT2);
            }
        });

        direct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callFragment(FRAGMENT3);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                callFragment(FRAGMENT4);

                AlertDialog.Builder builder = new AlertDialog.Builder(TabActivity.this);     // 여기서 this는 Activity의 this
                // 여기서 부터는 알림창의 속성 설정
                builder.setTitle("로그아웃")// 제목 설정
                        .setMessage("로그아웃 하시겠습니까?")// 메세지 설정
                        .setCancelable(false)// 뒤로 버튼 클릭시 취소 가능 설정
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            // 확인 버튼 클릭시 설정
                            public void onClick(DialogInterface dialog, int whichButton) {
                                //SharedPreferences에 저장된 값들을 로그아웃 버튼을 누르면 삭제하기 위해
                                //SharedPreferences를 불러옵니다. 메인에서 만든 이름으로
                                Intent intent = new Intent(TabActivity.this, MainActivity.class);
                                startActivity(intent);
                                SharedPreferences auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
                                SharedPreferences.Editor editor = auto.edit();
                                //editor.clear()는 auto에 들어있는 모든 정보를 기기에서 지웁니다.
                                editor.clear();
                                editor.commit();
                                Toast.makeText(TabActivity.this, "로그아웃 하였습니다.", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        })
                        .setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.cancel();
                                Toast.makeText(TabActivity.this, "로그아웃 취소하였습니다.", Toast.LENGTH_SHORT).show();
                            }
                        });
                AlertDialog dialog = builder.create();// 알림창 객체 생성
                dialog.show();// 알림창 띄우기
            }
        });

        callFragment(FRAGMENT1);
    }

    @Override
    protected void attachBaseContext(Context newBase) {

        super.attachBaseContext(TypekitContextWrapper.wrap(newBase));

    }

    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if (0 <= intervalTime && FINISH_INTERVAL_TIME >= intervalTime) {
            super.onBackPressed();
        } else {
            backPressedTime = tempTime;
            toast = Toast.makeText(getApplicationContext(), "앱을 종료하려면,\n뒤로가기 버튼을 한번 더 눌러주세요.", Toast.LENGTH_SHORT);
            toastLayout = (LinearLayout) toast.getView();
            toastTV = (TextView) toastLayout.getChildAt(0);
            toast.show();
        }
    }

    public void callFragment(int fragment_no) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        switch (fragment_no) {
            case 1:
                // '프래그먼트1' 호출
                PayActivity fragment1 = new PayActivity();
                transaction.replace(R.id.fragment_container, fragment1);
                transaction.commit();
                // id 보내기 open
                Bundle bundle1 = new Bundle();
                bundle1.putString("p_id", t_id);
                Log.d("페이 아이디", t_id);
                fragment1.setArguments(bundle1);
                // close
                pay.setBackground(ContextCompat.getDrawable(this, R.drawable.pay_btn));
//                income.setBackgroundColor(Color.parseColor("#fffdc0"));
                report.setBackgroundColor(Color.parseColor("#fffdc0"));
                direct.setBackgroundColor(Color.parseColor("#c0ffea"));
                logout.setBackgroundColor(Color.parseColor("#d8c0ff"));
                break;

            case 2:
                // '프래그먼트2' 호출
                ReportActivity fragment2 = new ReportActivity();
                transaction.replace(R.id.fragment_container, fragment2);
                transaction.commit();
                // id 보내기 open
                Bundle bundle2 = new Bundle();
                bundle2.putString("r_id", t_id);
                fragment2.setArguments(bundle2);
                // close
                pay.setBackgroundColor(Color.parseColor("#ffc0c0"));
                report.setBackground(ContextCompat.getDrawable(this, R.drawable.report_btn));
                direct.setBackgroundColor(Color.parseColor("#c0ffea"));
                logout.setBackgroundColor(Color.parseColor("#d8c0ff"));
                break;

            case 3:
                // '프래그먼트3' 호출
                RegDirectActivity fragment3 = new RegDirectActivity();
                transaction.replace(R.id.fragment_container, fragment3);
                transaction.commit();
                // id 보내기 open
                Bundle bundle3 = new Bundle();
                bundle3.putString("d_id", t_id);
                fragment3.setArguments(bundle3);
                // close
                pay.setBackgroundColor(Color.parseColor("#ffc0c0"));
                report.setBackgroundColor(Color.parseColor("#fffdc0"));
                direct.setBackground(ContextCompat.getDrawable(this, R.drawable.direct_btn));
                logout.setBackgroundColor(Color.parseColor("#d8c0ff"));
                break;

//            case 4:
//                // '프래그먼트4' 호출
//                RegDirectActivity fragment4 = new RegDirectActivity();
//                transaction.replace(R.id.fragment_container, fragment4);
//                transaction.commit();
//                // id 보내기 open
//                Bundle bundle4 = new Bundle();
//                bundle4.putString("d_id", t_id);
//                fragment4.setArguments(bundle4);
//                // close
//                pay.setBackgroundColor(Color.parseColor("#ffc0c0"));
//                income.setBackgroundColor(Color.parseColor("#fffdc0"));
//                report.setBackgroundColor(Color.parseColor("#c0ffea"));
//                direct.setBackground(ContextCompat.getDrawable(this, R.drawable.logout_btn));
//                break;
        }
    }
}
