package com.example.bgk.moga1105;

import java.util.Date;

// my global variable's area
public class MyGlobalV {
    private String g_sender;
    private String g_message;
    private String g_receivedDate;
    private String g_where;
    private String g_won;
    private String g_card;

    public String getG_card() {
        return g_card;
    }

    public void setG_card(String g_card) {
        this.g_card = g_card;
    }

    public String getG_where() {
        return g_where;
    }

    public void setG_where(String g_where) {
        this.g_where = g_where;
    }

    public String getG_won() {
        return g_won;
    }

    public void setG_won(String g_won) {
        this.g_won = g_won;
    }

    public String getG_sender() {
        return g_sender;
    }

    public void setG_sender(String g_sender) {
        this.g_sender = g_sender;
    }

    public String getG_message() {
        return g_message;
    }

    public void setG_message(String g_message) {
        this.g_message = g_message;
    }

    public String getG_receivedDate() {
        return g_receivedDate;
    }

    public void setG_receivedDate(String g_receivedDate) {
        this.g_receivedDate = g_receivedDate;
    }

    private String my_ip;

    public String getMy_ip() {
        //내 핫스팟 주소
//        my_ip = "http://192.168.43.55:8080/MOGA/";
        my_ip = "http://172.30.1.37:8080/MOGA/";
        return my_ip;
    }

    public void setMy_ip(String my_ip) {
        this.my_ip = my_ip;
    }

    private static MyGlobalV mgv_instance = null;

    public static synchronized MyGlobalV getInstance() {
        if(null == mgv_instance) {
            mgv_instance = new MyGlobalV();
        }

        return mgv_instance;
    }
}
