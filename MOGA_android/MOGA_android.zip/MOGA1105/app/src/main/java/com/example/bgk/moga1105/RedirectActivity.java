package com.example.bgk.moga1105;

import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class RedirectActivity extends AppCompatActivity {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();

        String r_card = intent.getStringExtra("v_card");
        String r_sender = intent.getStringExtra("sender");
        String r_where = intent.getStringExtra("v_where");
        String r_won = intent.getStringExtra("v_won");
        String r_receivedDate = intent.getStringExtra("receivedDate");

        Log.d("여기는_리다이렉트", "r_card : " + r_card);
        Log.d("여기는_리다이렉트", "Sender : " + r_sender);
        Log.d("여기는_리다이렉트", "r_where : " + r_where);
        Log.d("여기는_리다이렉트", "r_won : " + r_won);
        Log.d("여기는_리다이렉트", "receivedDate : " + r_receivedDate);

        MyGlobalV.getInstance().setG_card(r_card);
        MyGlobalV.getInstance().setG_sender(r_sender);
        MyGlobalV.getInstance().setG_where(r_where);
        MyGlobalV.getInstance().setG_won(r_won);
        MyGlobalV.getInstance().setG_receivedDate(r_receivedDate);

        Log.d("여기는_리다이렉트", "r_card : " + MyGlobalV.getInstance().getG_card());
        Log.d("여기는_리다이렉트", "Sender : " + MyGlobalV.getInstance().getG_sender());
        Log.d("여기는_리다이렉트", "r_where : " + MyGlobalV.getInstance().getG_where());
        Log.d("여기는_리다이렉트", "r_won : " + MyGlobalV.getInstance().getG_won());
        Log.d("여기는_리다이렉트", "receivedDate : " + MyGlobalV.getInstance().getG_receivedDate());

        intent.setClass(RedirectActivity.this, SmsTestActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();

    }
}
