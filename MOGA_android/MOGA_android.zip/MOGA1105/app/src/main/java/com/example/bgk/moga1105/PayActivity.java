package com.example.bgk.moga1105;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

public class PayActivity extends Fragment {
    public PayActivity() {
    }

    View pay_view;

    String IP = MyGlobalV.getInstance().getMy_ip();

    ListView pay_listview;
    ListViewAdapter listviewAdapter;
    ListViewItem listItem;
    ArrayList<ListViewItem> listviewItemList = new ArrayList<ListViewItem>();

    int list_cnt;
    String[] p_years;
    String[] p_months;
    String[] p_days;
    String[] p_hours;
    String[] p_minutes;
    String[] p_wheres;
    String[] p_whats;
    String[] p_costs;
    String[] p_payways;
    String[] p_payway_ms;
    String[] p_category_s;
    String p_date;
    String p_time;
    String p_won;

    String p_id;
    String result;

    JSONObject result_json = null;

    Spinner pay_year_choice;
    Spinner pay_month_choice;
    Spinner pay_payway_choice;

    Spinner pay_category_choice;
    Button pay_search_btn;
    Button pay_all_btn;


    private static final String[] pay_year_choice_array = {"2011", "2012", "2013", "2014",
            "2015", "2016", "2017", "2018", "2019", "2020"};
    private static final String[] pay_month_choice_array = {"1", "2", "3", "4", "5", "6",
            "7", "8", "9", "10", "11", "12"};
    private static final String[] pay_payway_choice_array = {"전체", "현금", "신한", "국민", "우리", "하나", "농협"};
    private static final String[] pay_category_choice_array = {"전체", "식비", "문화생활비", "주거생활비", "건강관리비", "교통비", "차량유지비", "쇼핑비", "미용비", "교육비", "사회생활비", "유흥비", "금융보험비", "저축", "기타"};

    private ArrayAdapter<String> spinner_adapter1;
    private ArrayAdapter<String> spinner_adapter2;
    private ArrayAdapter<String> spinner_adapter3;
    private ArrayAdapter<String> spinner_adapter4;

    String pay_year_choice_s;
    String pay_month_choice_s;
    String pay_payway_choice_s;
    String pay_category_choice_s;

    Calendar current;
    int currentYear;
    int currentMonth;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        pay_view = inflater.inflate(R.layout.activity_pay, container, false);

        current = Calendar.getInstance();
        currentYear = current.get(Calendar.YEAR);
        currentMonth = current.get(Calendar.MONTH);

        spinner_adapter1 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, pay_year_choice_array);
        spinner_adapter1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        pay_year_choice = (Spinner) pay_view.findViewById(R.id.pay_year_choice);
        pay_year_choice.setAdapter(spinner_adapter1);

        //스피너 선택을 string 값으로 하는 방법
        pay_year_choice.setSelection(spinner_adapter1.getPosition(Integer.toString(currentYear)));

        spinner_adapter2 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, pay_month_choice_array);
        spinner_adapter2.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        pay_month_choice = (Spinner) pay_view.findViewById(R.id.pay_month_choice);
        pay_month_choice.setAdapter(spinner_adapter2);

        //스피너 선택을 string 값으로 하는 방법
        pay_month_choice.setSelection(spinner_adapter2.getPosition(Integer.toString(currentMonth + 1)));

        spinner_adapter3 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, pay_payway_choice_array);
        spinner_adapter3.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        pay_payway_choice = (Spinner) pay_view.findViewById(R.id.pay_payway_choice);
        pay_payway_choice.setAdapter(spinner_adapter3);

        //스피너 선택을 string 값으로 하는 방법
        pay_payway_choice.setSelection(spinner_adapter3.getPosition("전체"));

        spinner_adapter4 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, pay_category_choice_array);
        spinner_adapter4.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        pay_category_choice = (Spinner) pay_view.findViewById(R.id.pay_category_choice);
        pay_category_choice.setAdapter(spinner_adapter4);

        //스피너 선택을 string 값으로 하는 방법
        pay_category_choice.setSelection(spinner_adapter4.getPosition("전체"));

        pay_search_btn = (Button) pay_view.findViewById(R.id.pay_search_btn);

        // id 받기 open
        Bundle bundle1 = this.getArguments();
        if (bundle1 != null) {
            p_id = bundle1.getString("p_id");
        }
        Log.d("페이 아이디", p_id);
        // close

        pay_search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pay_year_choice_s = pay_year_choice.getSelectedItem().toString();
                pay_month_choice_s = pay_month_choice.getSelectedItem().toString();
                pay_payway_choice_s = pay_payway_choice.getSelectedItem().toString();
                pay_category_choice_s = pay_category_choice.getSelectedItem().toString();

                Log.d("선택 값", pay_year_choice_s + "/" + pay_month_choice_s + "/" + pay_payway_choice_s + "/" + pay_category_choice_s);

                try {
                    String result = "";
                    PayTask task = new PayTask();

                    result = task.execute(p_id, pay_year_choice_s, pay_month_choice_s, pay_payway_choice_s, pay_category_choice_s).get();

                    Log.i("지출 내역 테이블", result);

                    result_json = new JSONObject(result);
                } catch (Exception e) {

                }

                pay_listview = (ListView) pay_view.findViewById(R.id.pay_listview);
                listviewAdapter = new ListViewAdapter();
                pay_listview.setAdapter(listviewAdapter);

                PayReader();
            }
        });

        return pay_view;
    }

    class PayTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;

        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaPayReader.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());

                sendMsg = "id=" + strings[0] + "&year=" + strings[1] + "&month=" + strings[2] + "&payway=" + strings[3] + "&category=" + strings[4];

                osw.write(sendMsg);
                osw.flush();
                if (conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "EUC-KR");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode() + "에러");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    private void PayReader() {
        try {
            JSONArray jsonArray = result_json.getJSONArray("PayData");

            list_cnt = jsonArray.length();
            Log.e("array_count", list_cnt + "");

            p_years = new String[list_cnt];
            p_months = new String[list_cnt];
            p_days = new String[list_cnt];
            p_hours = new String[list_cnt];
            p_minutes = new String[list_cnt];
            p_wheres = new String[list_cnt];
            p_whats = new String[list_cnt];
            p_costs = new String[list_cnt];
            p_payways = new String[list_cnt];
            p_payway_ms = new String[list_cnt];
            p_category_s = new String[list_cnt];

            for (int i = 0; i < list_cnt; i++) {
                JSONObject jObject = jsonArray.getJSONObject(i);
                listItem = new ListViewItem();

                Log.e("JSON Object", jObject + "");
                p_years[i] = jObject.getString("p_year");
                p_months[i] = jObject.getString("p_month");
                p_days[i] = jObject.getString("p_day");
                p_hours[i] = jObject.getString("p_hour");
                p_minutes[i] = jObject.getString("p_minute");
                p_wheres[i] = jObject.getString("p_where");
                p_whats[i] = jObject.getString("p_what");
                p_costs[i] = jObject.getString("p_cost");
                p_payways[i] = jObject.getString("p_payway");
                p_payway_ms[i] = jObject.getString("p_payway_m");
                p_category_s[i] = jObject.getString("p_category");

                p_date = p_years[i] + " / " + p_months[i] + " / " + p_days[i];
                p_time = p_hours[i] + " : " + p_minutes[i];
                p_won = Currency.getInstance(Locale.KOREA).getSymbol() + p_costs[i];

                listItem.setDate_list(p_date);
                listItem.setTime_list(p_time);
                listItem.setPayway_list(p_payways[i]);
                listItem.setPayway_m_list(p_payway_ms[i]);
                listItem.setWhere_list(p_wheres[i]);
                listItem.setWhat_list(p_whats[i]);
                listItem.setCost_list(p_won);
                listItem.setCategory_list(p_category_s[i]);

                listviewItemList.add(listItem);
                listviewAdapter.addItem(p_date, p_time, p_payways[i], p_payway_ms[i]
                        , p_wheres[i], p_whats[i], p_won, p_category_s[i]);
//              listviewAdapter.notifyDataSetChanged();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
