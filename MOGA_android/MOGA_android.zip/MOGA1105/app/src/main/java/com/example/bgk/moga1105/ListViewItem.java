package com.example.bgk.moga1105;

// items for pay & income listview
public class ListViewItem {
    private String date_list;
    private String day_sum_list;
    private String time_list;
    private String payway_list;
    private String payway_m_list;
    private String where_list;
    private String what_list;
    private String cost_list;
    private String category_list;

    public String getCategory_list() {
        return category_list;
    }

    public void setCategory_list(String category_list) {
        this.category_list = category_list;
    }

    public String getDate_list() {
        return date_list;
    }

    public void setDate_list(String date_list) {
        this.date_list = date_list;
    }

    public String getDay_sum_list() {
        return day_sum_list;
    }

    public void setDay_sum_list(String day_sum_list) {
        this.day_sum_list = day_sum_list;
    }

    public String getTime_list() {
        return time_list;
    }

    public void setTime_list(String time_list) {
        this.time_list = time_list;
    }

    public String getPayway_list() {
        return payway_list;
    }

    public void setPayway_list(String payway_list) {
        this.payway_list = payway_list;
    }

    public String getPayway_m_list() {
        return payway_m_list;
    }

    public void setPayway_m_list(String payway_m_list) {
        this.payway_m_list = payway_m_list;
    }

    public String getWhere_list() {
        return where_list;
    }

    public void setWhere_list(String where_list) {
        this.where_list = where_list;
    }

    public String getWhat_list() {
        return what_list;
    }

    public void setWhat_list(String what_list) {
        this.what_list = what_list;
    }

    public String getCost_list() {
        return cost_list;
    }

    public void setCost_list(String cost_list) {
        this.cost_list = cost_list;
    }
}
