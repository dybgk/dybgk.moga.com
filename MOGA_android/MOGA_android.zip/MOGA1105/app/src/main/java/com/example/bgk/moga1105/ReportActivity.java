package com.example.bgk.moga1105;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.List;
import java.util.Locale;

public class ReportActivity extends Fragment {
    public ReportActivity() {
    }

    View report_view;

    String IP = MyGlobalV.getInstance().getMy_ip();

    TextView pay_sum;
    TextView income_sum;
    TextView report_sum;

    int pay_sum_i;
    int income_sum_i;
    int report_sum_i;

    String r_id;

    JSONObject result_json = null;

    Spinner report_year_choice;
    Spinner report_month_choice;

    private static final String[] report_year_choice_array = {"2011", "2012", "2013", "2014",
            "2015", "2016", "2017", "2018", "2019", "2020"};
    private static final String[] report_month_choice_array = {"1", "2", "3", "4", "5", "6",
            "7", "8", "9", "10", "11", "12"};

    private ArrayAdapter<String> spinner_adapter1;
    private ArrayAdapter<String> spinner_adapter2;

    String report_year_choice_s;
    String report_month_choice_s;

    int list_cnt;
    String sum_p;
    String sum_i;
    String sum_r;

    //new
    Button report_payway_all_btn;
    Button report_category_all_btn;
    //new

    //추
    Calendar current;
    int currentYear;
    int currentMonth;

    //파이차트
    private PieChart pieChart;
//    private ChartView mChartView;
    private RelativeLayout chart_layout;

    //NEW 파이차트
    int[] pieChartValues;  //각 계열(Series)의 값
    public static final String TYPE = "type";

    //각 계열(Series)의 색상 추가해야돼.
    private static int[] COLORS = new int[]{Color.parseColor("#614190"), Color.parseColor("#b563a6"), Color.parseColor("#dfb2d3"),
            Color.parseColor("#ac7d85"), Color.parseColor("#e5998c"), Color.parseColor("#ece2e3")};
//    private static int[] COLORS = new int[]{Color.RED, Color.YELLOW, Color.GRAY, Color.BLUE, Color.GREEN, Color.BLACK};

    //각 계열의 타이틀
    String[] mSeriesTitle = new String[] {"현금", "신한", "국민", "우리", "하나", "농협"};
    private CategorySeries mSeries = new CategorySeries("결제 수단");
    private DefaultRenderer mRenderer = new DefaultRenderer();
    private GraphicalView mChartView;

    //new
    String[] mSeriesTitle2 = new String[] {"식비", "문화생활비", "주거생활비", "건강관리비", "교통비", "차량유지비", "쇼핑비", "미용비", "교육비", "사회생활비", "유흥비", "금융보험비", "저축", "기타"};
    private CategorySeries mSeries2 = new CategorySeries("카테고리");
    private DefaultRenderer mRenderer2 = new DefaultRenderer();
    private GraphicalView mChartView2;
    //new

    //합계 가져오는 변수
    String sum_money;
    String sum_shin;
    String sum_kook;
    String sum_woo;
    String sum_ha;
    String sum_nong;

    //new
    String sum_sik;
    String sum_moon;
    String sum_joo;
    String sum_geon;
    String sum_kt;
    String sum_cha;
    String sum_sho;
    String sum_mi;
    String sum_ky;
    String sum_sa;
    String sum_yoo;
    String sum_kb;
    String sum_jeo;
    String sum_ki;
    //new

    int money_num;
    int shin_num;
    int kook_num;
    int woo_num;
    int ha_num;
    int nong_num;
    int total_num;

    //new
    int sik_num;
    int moon_num;
    int joo_num;
    int geon_num;
    int kt_num;
    int cha_num;
    int sho_num;
    int mi_num;
    int ky_num;
    int sa_num;
    int yoo_num;
    int kb_num;
    int jeo_num;
    int ki_num;
    int category_total_num;
    //new

    LinearLayout layout;
    //가

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        report_view = inflater.inflate(R.layout.activity_report, container, false);

//        pay_sum = (TextView)report_view.findViewById(R.id.pay_sum);
//        income_sum = (TextView)report_view.findViewById(R.id.income_sum);
//        report_sum = (TextView)report_view.findViewById(R.id.report_sum);

        //추
//        //achartengine 선언
//        chart_layout = (RelativeLayout)report_view.findViewById(R.id.chart_layout);
//
//        //차트를 출력하는 뷰객체(ChartView) 생성
//        mChartView = new ChartView(getContext());
//
//        //리니어 레이아웃에 차트뷰 추가( 폭, 높이 가득차게 )
//        chart_layout.addView(mChartView, new RelativeLayout.LayoutParams(
//                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT));
//
//        //차트 그리기
//        mChartView.makeChart();
        //가

        //추
        current = Calendar.getInstance();
        currentYear = current.get(Calendar.YEAR);
        currentMonth = current.get(Calendar.MONTH);
        //가

        spinner_adapter1 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, report_year_choice_array);
        spinner_adapter1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        report_year_choice = (Spinner) report_view.findViewById(R.id.report_year_choice);
        report_year_choice.setAdapter(spinner_adapter1);
//        report_year_choice.setSelection(7);
        //추
        report_year_choice.setSelection(spinner_adapter1.getPosition(Integer.toString(currentYear)));
        //가

        spinner_adapter2 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, report_month_choice_array);
        spinner_adapter2.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        report_month_choice = (Spinner) report_view.findViewById(R.id.report_month_choice);
        report_month_choice.setAdapter(spinner_adapter2);
//        report_month_choice.setSelection(5);
        //추
        report_month_choice.setSelection(spinner_adapter2.getPosition(Integer.toString(currentMonth+1)));
        //가

        // id 받기 open
        Bundle bundle3 = this.getArguments();
        if (bundle3 != null) {
            r_id = bundle3.getString("r_id");
        }
        Log.d("리포트 아이디", r_id);
        // close

        //new
        report_payway_all_btn = (Button) report_view.findViewById(R.id.report_payway_all_btn);
        report_category_all_btn = (Button) report_view.findViewById(R.id.report_category_all_btn);

        report_payway_all_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                report_year_choice_s = report_year_choice.getSelectedItem().toString();
                report_month_choice_s = report_month_choice.getSelectedItem().toString();

                try {
                    String result= "";
                    ReportTask task = new ReportTask();
                    result = task.execute(r_id, report_year_choice_s, report_month_choice_s).get();
                    Log.i("결제수단 통계 테이블", result);

                    result_json = new JSONObject(result);
                } catch (Exception e) {

                }

                ReportReader();

                Log.d("결제수단 통계 string값 확인", "sum_money: " + sum_money
                        + "\nsum_shin: " + sum_shin
                        + "\nsum_kook: " + sum_kook
                        + "\nsum_woo: " + sum_woo
                        + "\nsum_ha: " + sum_ha
                        + "\nsum_nong: " + sum_nong);

                //null 값 대비
//                money_num = (sum_money != null) ? Integer.parseInt(sum_money) : (int)0.0;
//                shin_num = (sum_shin != null) ? Integer.parseInt(sum_shin) : (int)0.0;
//                kook_num = (sum_kook != null) ? Integer.parseInt(sum_kook) : (int)0.0;
//                woo_num = (sum_woo != null) ? Integer.parseInt(sum_woo) : (int)0.0;
//                ha_num = (sum_ha != null) ? Integer.parseInt(sum_ha) : (int)0.0;
//                nong_num = (sum_nong != null) ? Integer.parseInt(sum_nong) : (int)0.0;

//                money_num = (!sum_money.equals(null)) ? Integer.parseInt(sum_money) : (int)0.0;
//                shin_num = (!sum_shin.equals(null)) ? Integer.parseInt(sum_shin) : (int)0.0;
//                kook_num = (!sum_kook.equals(null)) ? Integer.parseInt(sum_kook) : (int)0.0;
//                woo_num = (!sum_woo.equals(null)) ? Integer.parseInt(sum_woo) : (int)0.0;
//                ha_num = (!sum_ha.equals(null)) ? Integer.parseInt(sum_ha) : (int)0.0;
//                nong_num = (!sum_nong.equals(null)) ? Integer.parseInt(sum_nong) : (int)0.0;

                money_num = Integer.parseInt(sum_money);
                shin_num = Integer.parseInt(sum_shin);
                kook_num = Integer.parseInt(sum_kook);
                woo_num = Integer.parseInt(sum_woo);
                ha_num = Integer.parseInt(sum_ha);
                nong_num = Integer.parseInt(sum_nong);

//                Log.d("결제수단 통계 num값 확인", "money_num: " + Integer.toString(money_num)
//                        + "\nshin_num: " + Integer.toString(shin_num)
//                        + "\nkook_num: " + Integer.toString(kook_num)
//                        + "\nwoo_num: " + Integer.toString(woo_num)
//                        + "\nha_num: " + Integer.toString(ha_num)
//                        + "\nnong_num: " + Integer.toString(nong_num));

                Log.d("결제수단 통계 num값 확인", "money_num: " + money_num
                        + "\nshin_num: " + shin_num
                        + "\nkook_num: " + kook_num
                        + "\nwoo_num: " + woo_num
                        + "\nha_num: " + ha_num
                        + "\nnong_num: " + nong_num);

                total_num = money_num+shin_num+kook_num+woo_num+ha_num+nong_num;

                //NEW 파이차트
                makeReportChart(Integer.toString(currentYear), Integer.toString(currentMonth+1), money_num, shin_num,
                        kook_num, woo_num, ha_num, nong_num, total_num);

            }
        });

        report_category_all_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                report_year_choice_s = report_year_choice.getSelectedItem().toString();
                report_month_choice_s = report_month_choice.getSelectedItem().toString();

                try {
                    String result = "";
                    CategoryReportTask task = new CategoryReportTask();
                    result = task.execute(r_id, report_year_choice_s, report_month_choice_s).get();
                    Log.i("카테고리 통계 테이블", result);

                    result_json = new JSONObject(result);
                } catch (Exception e) {

                }

                CategoryReportReader();

                Log.d("카테고리 통계 string값 확인", sum_joo+"");

//                Log.d("카테고리 통계 string값 확인", "sum_money: " + sum_money
//                        + "\nsum_shin: " + sum_shin
//                        + "\nsum_kook: " + sum_kook
//                        + "\nsum_woo: " + sum_woo
//                        + "\nsum_ha: " + sum_ha
//                        + "\nsum_nong: " + sum_nong);

                //null 값 대비
//                sik_num = (sum_sik != null) ? Integer.parseInt(sum_sik) : (int)0.0;
//                moon_num = (sum_moon != null) ? Integer.parseInt(sum_moon) : (int)0.0;
//                joo_num = (sum_joo != null) ? Integer.parseInt(sum_joo) : (int)0.0;
//                geon_num = (sum_geon != null) ? Integer.parseInt(sum_geon) : (int)0.0;
//                kt_num = (sum_kt != null) ? Integer.parseInt(sum_kt) : (int)0.0;
//                cha_num = (sum_cha != null) ? Integer.parseInt(sum_cha) : (int)0.0;
//                sho_num = (sum_sho != null) ? Integer.parseInt(sum_sho) : (int)0.0;
//                mi_num = (sum_mi != null) ? Integer.parseInt(sum_mi) : (int)0.0;
//                ky_num = (sum_ky != null) ? Integer.parseInt(sum_ky) : (int)0.0;
//                sa_num = (sum_sa != null) ? Integer.parseInt(sum_sa) : (int)0.0;
//                yoo_num = (sum_yoo != null) ? Integer.parseInt(sum_yoo) : (int)0.0;
//                kb_num = (sum_kb != null) ? Integer.parseInt(sum_kb) : (int)0.0;
//                jeo_num = (sum_jeo != null) ? Integer.parseInt(sum_jeo) : (int)0.0;
//                ki_num = (sum_ki != null) ? Integer.parseInt(sum_ki) : (int)0.0;

//                sik_num = ((sum_sik != null) && !sum_sik.isEmpty()) ? Integer.parseInt(sum_sik) : 0;
//                moon_num = ((sum_moon != null) && !sum_moon.isEmpty()) ? Integer.parseInt(sum_moon) : 0;
//                joo_num = ((sum_joo != null) && !sum_joo.isEmpty()) ? Integer.parseInt(sum_joo) : 0;
//                geon_num = ((sum_geon != null) && !sum_geon.isEmpty()) ? Integer.parseInt(sum_geon) : 0;
//                kt_num = ((sum_kt != null) && !sum_kt.isEmpty()) ? Integer.parseInt(sum_kt) : 0;
//                cha_num = ((sum_cha != null) && !sum_cha.isEmpty()) ? Integer.parseInt(sum_cha) : 0;
//                sho_num = ((sum_sho != null) && !sum_sho.isEmpty()) ? Integer.parseInt(sum_sho) : 0;
//                mi_num = ((sum_mi != null) && !sum_mi.isEmpty()) ? Integer.parseInt(sum_mi) : 0;
//                ky_num = ((sum_ky != null) && !sum_ky.isEmpty()) ? Integer.parseInt(sum_ky) : 0;
//                sa_num = ((sum_sa != null) && !sum_sa.isEmpty()) ? Integer.parseInt(sum_sa) : 0;
//                yoo_num = ((sum_yoo != null) && !sum_yoo.isEmpty()) ? Integer.parseInt(sum_yoo) : 0;
//                kb_num = ((sum_kb != null) && !sum_kb.isEmpty()) ? Integer.parseInt(sum_kb) : 0;
//                jeo_num = ((sum_jeo != null) && !sum_jeo.isEmpty()) ? Integer.parseInt(sum_jeo) : 0;
//                ki_num = ((sum_ki != null) && !sum_ki.isEmpty()) ? Integer.parseInt(sum_ki) : 0;

                sik_num =Integer.parseInt(sum_sik);
                moon_num = Integer.parseInt(sum_moon);
                joo_num = Integer.parseInt(sum_joo);
                geon_num = Integer.parseInt(sum_geon);
                kt_num = Integer.parseInt(sum_kt);
                cha_num = Integer.parseInt(sum_cha);
                sho_num = Integer.parseInt(sum_sho);
                mi_num = Integer.parseInt(sum_mi);
                ky_num = Integer.parseInt(sum_ky);
                sa_num = Integer.parseInt(sum_sa);
                yoo_num = Integer.parseInt(sum_yoo);
                kb_num = Integer.parseInt(sum_kb);
                jeo_num = Integer.parseInt(sum_jeo);
                ki_num = Integer.parseInt(sum_ki);

//                Log.d("카테고리 통계 num값 확인", "money_num: " + Integer.toString(money_num)
//                        + "\nshin_num: " + Integer.toString(shin_num)
//                        + "\nkook_num: " + Integer.toString(kook_num)
//                        + "\nwoo_num: " + Integer.toString(woo_num)
//                        + "\nha_num: " + Integer.toString(ha_num)
//                        + "\nnong_num: " + Integer.toString(nong_num));

                Log.d("카테고리 통계 num값 확인", "sik_num"+Integer.toString(sik_num));

                category_total_num = sik_num+ moon_num+ joo_num+ geon_num+ kt_num+ cha_num+ sho_num+ mi_num+ ky_num+ sa_num+ yoo_num+ kb_num+ jeo_num+ ki_num;

                //NEW 파이차트
                makeCategoryReportChart(Integer.toString(currentYear), Integer.toString(currentMonth+1), sik_num, moon_num, joo_num, geon_num, kt_num, cha_num, sho_num, mi_num, ky_num, sa_num, yoo_num, kb_num, jeo_num, ki_num, category_total_num);
            }
        });

        /*report_month_choice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                report_year_choice_s = report_year_choice.getSelectedItem().toString();
                report_month_choice_s = report_month_choice.getSelectedItem().toString();

                try {
                    String result;
                    ReportTask task = new ReportTask();
                    result = task.execute(r_id, report_year_choice_s, report_month_choice_s).get();
                    Log.i("통계 테이블", result);

                    result_json = new JSONObject(result);
                } catch (Exception e) {

                }

                ReportReader();
                //여기까지 합계 값은 잘 온다.

                *//*옛날통계
                pay_sum.setText(Currency.getInstance(Locale.KOREA).getSymbol()+" "+sum_p);
                income_sum.setText(Currency.getInstance(Locale.KOREA).getSymbol()+" "+sum_i);
                report_sum.setText(Currency.getInstance(Locale.KOREA).getSymbol()+" "+sum_r);
                옛날통계*//*

                Log.d("통계 string값 확인", "sum_money: " + sum_money
                        + "\nsum_shin: " + sum_shin
                        + "\nsum_kook: " + sum_kook
                        + "\nsum_woo: " + sum_woo
                        + "\nsum_ha: " + sum_ha
                        + "\nsum_nong: " + sum_nong);

                //null 값 대비
                money_num = (sum_money != null) ? Integer.parseInt(sum_money) : (int)0.0;
                shin_num = (sum_shin != null) ? Integer.parseInt(sum_shin) : (int)0.0;
                kook_num = (sum_kook != null) ? Integer.parseInt(sum_kook) : (int)0.0;
                woo_num = (sum_woo != null) ? Integer.parseInt(sum_woo) : (int)0.0;
                ha_num = (sum_ha != null) ? Integer.parseInt(sum_ha) : (int)0.0;
                nong_num = (sum_nong != null) ? Integer.parseInt(sum_nong) : (int)0.0;

                //동일 내용을 if else 문으로
//                if (sum_money != null) money_num = Integer.parseInt(sum_money);
//                else money_num = (int) 0.0;
//                if (sum_shin != null) shin_num = Integer.parseInt(sum_shin);
//                else shin_num = (int) 0.0;
//                if (sum_kook != null) kook_num = Integer.parseInt(sum_kook);
//                else kook_num = (int) 0.0;
//                if (sum_woo != null) woo_num = Integer.parseInt(sum_woo);
//                else woo_num = (int) 0.0;
//                if (sum_ha != null) ha_num = Integer.parseInt(sum_ha);
//                else ha_num = (int) 0.0;
//                if (sum_nong != null) nong_num = Integer.parseInt(sum_nong);
//                else nong_num = (int) 0.0;

                Log.d("통계 num값 확인", "money_num: " + Integer.toString(money_num)
                        + "\nshin_num: " + Integer.toString(shin_num)
                        + "\nkook_num: " + Integer.toString(kook_num)
                        + "\nwoo_num: " + Integer.toString(woo_num)
                        + "\nha_num: " + Integer.toString(ha_num)
                        + "\nnong_num: " + Integer.toString(nong_num));

//                if(sum_money.isEmpty()) {
//                    money_num = 0;
//                } else {
//                    money_num = Integer.parseInt(sum_money);
//                }
//                if(sum_shin == null) {
//                    shin_num = 0;
//                } else {
//                    money_num = Integer.parseInt(sum_shin);
//                }
//                if(sum_kook == null) {
//                    kook_num = 0;
//                } else {
//                    money_num = Integer.parseInt(sum_kook);
//                }
//                if(sum_woo == null) {
//                    woo_num = 0;
//                } else {
//                    money_num = Integer.parseInt(sum_woo);
//                }
//                if(sum_ha == null) {
//                    ha_num = 0;
//                } else {
//                    money_num = Integer.parseInt(sum_ha);
//                }
//                if(sum_shin == null) {
//                    nong_num = 0;
//                } else {
//                    money_num = Integer.parseInt(sum_nong);
//                }

                //string 을 int로 바꾸기
//                money_num = Integer.parseInt(sum_money);
//                shin_num = Integer.parseInt(sum_shin);
//                kook_num = Integer.parseInt(sum_kook);
//                woo_num = Integer.parseInt(sum_woo);
//                ha_num = Integer.parseInt(sum_ha);
//                nong_num = Integer.parseInt(sum_nong);
                total_num = money_num+shin_num+kook_num+woo_num+ha_num+nong_num;

                //NEW 파이차트
                makeReportChart(Integer.toString(currentYear), Integer.toString(currentMonth+1), money_num, shin_num,
                        kook_num, woo_num, ha_num, nong_num, total_num);

//                pieChart = (PieChart)report_view.findViewById(R.id.piechart);

                //파이차트~
                *//*pieChart = (PieChart)report_view.findViewById(R.id.piechart);
                pieChart.setUsePercentValues(true);
                pieChart.getDescription().setEnabled(false);
                pieChart.setExtraOffsets(5,0,5,0);

                pieChart.setDragDecelerationFrictionCoef(0.95f);

                pieChart.setDrawHoleEnabled(false);
                pieChart.setHoleColor(Color.WHITE);
                pieChart.setTransparentCircleRadius(61f);

                ArrayList<PieEntry> yValues = new ArrayList<PieEntry>();

                yValues.add(new PieEntry((float)money_num,"현금"));
                yValues.add(new PieEntry((float)shin_num,"신한"));
                yValues.add(new PieEntry((float)kook_num,"국민"));
                yValues.add(new PieEntry((float)woo_num,"우리"));
                yValues.add(new PieEntry((float)ha_num,"하나"));
                yValues.add(new PieEntry((float)nong_num,"농협"));

                Description description = new Description();
                description.setText(report_month_choice_s + "월 지출 : " + Currency.getInstance(Locale.KOREA).getSymbol() + " "
                        + total_num); //라벨
                description.setTextSize(20);
                pieChart.setDescription(description);

                pieChart.animateY(1000, Easing.EasingOption.EaseInOutCubic); //애니메이션

                PieDataSet dataSet = new PieDataSet(yValues,"[ 결제수단, 단위: % ]");
                dataSet.setSliceSpace(3f);
                dataSet.setSelectionShift(5f);
//                dataSet.setColors(ColorTemplate.JOYFUL_COLORS);
                dataSet.setColors(ColorTemplate.JOYFUL_COLORS);
                dataSet.setDrawIcons(false);
                dataSet.setIconsOffset(new MPPointF(0, 40));

                PieData data = new PieData(dataSet);
                data.setValueTextSize(17f);
                data.setValueTextColor(Color.YELLOW);
//                data.setValueFormatter(new PercentFormatter(pieChart));

                pieChart.setData(data);

                pieChart.highlightValues(null);

                pieChart.invalidate();*//*
                //~파이차트

                //파이차트2~
//                List<PieEntry> entries = new ArrayList<>();
//
//                entries.add(new PieEntry((float)money_num,"현금"));
//                entries.add(new PieEntry((float)shin_num,"신한"));
//                entries.add(new PieEntry((float)kook_num,"국민"));
//                entries.add(new PieEntry((float)woo_num,"우리"));
//                entries.add(new PieEntry((float)ha_num,"하나"));
//                entries.add(new PieEntry((float)nong_num,"농협"));
//
//                PieDataSet set = new PieDataSet(entries, "** 결제수단");
//                PieData data2 = new PieData(set);
//                pieChart.setData(data2);
//                pieChart.invalidate(); // refresh
                //~파이차트2

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/

        return report_view;
    }

    private void makeReportChart (String year, String month, int money_num, int shin_num, int kook_num,
                                  int woo_num, int ha_num, int nong_num, int total_num) {
        pieChartValues = new int[]{money_num, shin_num, kook_num, woo_num, ha_num, nong_num};  //각 계열(Series)의 값

        mRenderer.setApplyBackgroundColor(true);
        mRenderer.setBackgroundColor(Color.TRANSPARENT);
        mRenderer.setChartTitle("※ "+year+"년 "+month+"월 결제수단 별 통계 (단위: 원) ※");
        mRenderer.setChartTitleTextSize(70);
        mRenderer.setLabelsTextSize(75);
        mRenderer.setLegendTextSize(75);
//        mRenderer.setMargins(new int[]{20, 30, 15, 0});
        mRenderer.setMargins(new int[]{0, 0, 5, 5});
        mRenderer.setZoomButtonsVisible(true);
        mRenderer.setStartAngle(-90);
        mRenderer.setLabelsColor(Color.BLACK);
        mRenderer.setDisplayValues(true);

        if (mChartView == null) {
            layout = (LinearLayout) report_view.findViewById(R.id.chart_pie);
            mChartView = ChartFactory.getPieChartView(getContext(), mSeries, mRenderer);
            mRenderer.setClickEnabled(true);
            mRenderer.setSelectableBuffer(10);
            layout.addView(mChartView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
        } else {
            mChartView.repaint();
        }

        //fillPieChart
        for (int i = 0; i < pieChartValues.length; i++) {
            mSeries.add(mSeriesTitle[i], pieChartValues[i]);

            //Chart에서 사용할 값, 색깔, 텍스트등을 DefaultRenderer객체에 설정
            SimpleSeriesRenderer renderer = new SimpleSeriesRenderer();
            renderer.setColor(COLORS[(mSeries.getItemCount() - 1) % COLORS.length]);

            mRenderer.addSeriesRenderer(renderer);

            if (mChartView != null) {
                mChartView.repaint();
            }
        }
    }

    class ReportTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;

        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaReportReader.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "id=" + strings[0] + "&year=" + strings[1] + "&month=" + strings[2];
                osw.write(sendMsg);
                osw.flush();
                if (conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "EUC-KR");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode() + "에러");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    private void ReportReader() {
        try {
            JSONArray jsonArray = result_json.getJSONArray("ReportData");

            list_cnt = jsonArray.length();
            Log.e("array_count", list_cnt + "");

            sum_money = new String();
            sum_shin = new String();
            sum_kook = new String();
            sum_woo = new String();
            sum_ha = new String();
            sum_nong = new String();

            JSONObject jObject = jsonArray.getJSONObject(0);

            Log.e("JSON Object", jObject + "");
            sum_money = jObject.getString("sum_money");
            sum_shin = jObject.getString("sum_shin");
            sum_kook = jObject.getString("sum_kook");
            sum_woo = jObject.getString("sum_woo");
            sum_ha = jObject.getString("sum_ha");
            sum_nong = jObject.getString("sum_nong");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void makeCategoryReportChart (String year, String month, int sik_num, int moon_num, int joo_num, int geon_num, int kt_num, int cha_num, int sho_num, int mi_num, int ky_num, int sa_num, int yoo_num, int kb_num, int jeo_num, int ki_num, int category_total_num) {
        pieChartValues = new int[]{sik_num, moon_num, joo_num, geon_num, kt_num, cha_num, sho_num, mi_num, ky_num, sa_num, yoo_num, kb_num, jeo_num, ki_num};  //각 계열(Series)의 값

        mRenderer2.setApplyBackgroundColor(true);
        mRenderer2.setBackgroundColor(Color.TRANSPARENT);
        mRenderer2.setChartTitle("※ "+year+"년 "+month+"월 카테고리 별 통계 (단위: 원) ※");
        mRenderer2.setChartTitleTextSize(70);
        mRenderer2.setLabelsTextSize(75);
        mRenderer2.setLegendTextSize(75);
//        mRenderer.setMargins(new int[]{20, 30, 15, 0});
        mRenderer2.setMargins(new int[]{0, 0, 5, 5});
        mRenderer2.setZoomButtonsVisible(true);
        mRenderer2.setStartAngle(-90);
        mRenderer2.setLabelsColor(Color.BLACK);
        mRenderer2.setDisplayValues(true);

        if (mChartView2 == null) {
            LinearLayout layout = (LinearLayout) report_view.findViewById(R.id.chart_pie);
            mChartView2 = ChartFactory.getPieChartView(getContext(), mSeries2, mRenderer2);
            mRenderer2.setClickEnabled(true);
            mRenderer2.setSelectableBuffer(10);
            layout.addView(mChartView2, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
        } else {
            mChartView2.repaint();
        }

        //fillPieChart
        for (int i = 0; i < pieChartValues.length; i++) {
            mSeries2.add(mSeriesTitle2[i], pieChartValues[i]);

            //Chart에서 사용할 값, 색깔, 텍스트등을 DefaultRenderer객체에 설정
            SimpleSeriesRenderer renderer = new SimpleSeriesRenderer();
            renderer.setColor(COLORS[(mSeries2.getItemCount() - 1) % COLORS.length]);

            mRenderer2.addSeriesRenderer(renderer);

            if (mChartView2 != null)
                mChartView2.repaint();

        }
    }

    class CategoryReportTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;

        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaCategoryReportReader.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "id=" + strings[0] + "&year=" + strings[1] + "&month=" + strings[2];
                osw.write(sendMsg);
                osw.flush();
                if (conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "EUC-KR");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode() + "에러");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    private void CategoryReportReader() {
        try {
            JSONArray jsonArray = result_json.getJSONArray("CategoryReportData");

            list_cnt = jsonArray.length();
            Log.e("array_count", list_cnt + "");

            sum_sik = new String();
            sum_moon = new String();
            sum_joo = new String();
            sum_geon = new String();
            sum_kt = new String();
            sum_cha = new String();
            sum_sho = new String();
            sum_mi = new String();
            sum_ky = new String();
            sum_sa = new String();
            sum_yoo = new String();
            sum_kb = new String();
            sum_jeo = new String();
            sum_ki = new String();

            JSONObject jObject = jsonArray.getJSONObject(0);

            Log.e("JSON Object", jObject + "");
            sum_sik = jObject.getString("sum_sik");
            sum_moon = jObject.getString("sum_moon");
            sum_joo = jObject.getString("sum_joo");
            sum_geon = jObject.getString("sum_geon");
            sum_kt = jObject.getString("sum_kt");
            sum_cha = jObject.getString("sum_cha");
            sum_sho = jObject.getString("sum_sho");
            sum_mi = jObject.getString("sum_mi");
            sum_ky = jObject.getString("sum_ky");
            sum_sa = jObject.getString("sum_sa");
            sum_yoo = jObject.getString("sum_yoo");
            sum_kb = jObject.getString("sum_kb");
            sum_jeo = jObject.getString("sum_jeo");
            sum_ki = jObject.getString("sum_ki");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
