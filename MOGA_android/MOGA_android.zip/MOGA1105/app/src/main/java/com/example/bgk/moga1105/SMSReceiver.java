package com.example.bgk.moga1105;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SMSReceiver extends BroadcastReceiver {
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    private static final String TAG = "SMSReceiver";

    private static SimpleDateFormat format = new SimpleDateFormat("yyyy년M월d일 H:m");

    private String sender = "";
    private String contents = "";
    private Date receivedDate = new Date();

    private String v_won;
    private String v_where;
    private String v_card;

    @Override
    public void onReceive(Context context, Intent intent) {
        // SMS_RECEIVED에 대한 액션일때 실행
        if (intent.getAction().equals(SMS_RECEIVED)) {
            Log.d(TAG, "onReceiver() 호출");

            // Bundle을 이용해서 메세지 내용을 가져옴
            Bundle bundle = intent.getExtras();
            SmsMessage[] messages = parseSmsMessage(bundle);
            // 메세지가 있을 경우 내용을 로그로 출력해 봄
            if (messages.length > 0) {
                // 메세지의 내용을 가져옴
                sender = messages[0].getOriginatingAddress();
                contents = messages[0].getMessageBody().toString();
                receivedDate = new Date(messages[0].getTimestampMillis());

                // 로그를 찍어보는 과정이므로 생략해도 됨
                Log.d("여기는_리시버", "Sender : " + sender);
                Log.d("여기는_리시버", "contents : " + contents);
                Log.d("여기는_리시버", "receivedDate : " + format.format(receivedDate));

                if(contents.contains("신한체크승인")) {
                    v_card = "신한";
                    toRedirect(context, intent);
                } else if(contents.contains("국민체크승인")) {
                    v_card = "국민";
                    toRedirect(context, intent);
                } else if(contents.contains("우리체크승인")) {
                    v_card = "우리";
                    toRedirect(context, intent);
                } else if(contents.contains("하나체크승인")) {
                    v_card = "하나";
                    toRedirect(context, intent);
                } else if(contents.contains("농협체크승인")) {
                    v_card = "농협";
                    toRedirect(context, intent);
                } else {
                    Log.d("삐용삐용", "문자열 못 읽었거나 카드 결제 문자가 아님!");
                }
            }
        }
    }

    // 액티비티로 메세지의 내용을 전달해줌
    private void toRedirect (Context context, Intent intent) {
        v_won = contents.substring(31, contents.indexOf("원 "));
        v_won = v_won.replace(",", "");
        v_where = contents.substring(contents.indexOf("원 ")+2, contents.indexOf(" 잔"));

        Log.d("여기는_리시버", "Sender : " + sender);
        Log.d("여기는_리시버", "v_where : " + v_where);
        Log.d("여기는_리시버", "v_won : " + v_won);
        Log.d("여기는_리시버", "receivedDate : " + format.format(receivedDate));

        intent.putExtra("v_card", v_card);
        intent.putExtra("sender", sender);
        intent.putExtra("v_where", v_where);
        intent.putExtra("v_won", v_won);
        intent.putExtra("receivedDate", format.format(receivedDate));
        intent.setClass(context, RedirectActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    // 지금은 사용하지 않음.
    private void sendToActivity(Context context, String sender, String contents, String receivedDate){
        Intent intent = new Intent(context, MainActivity.class);

        // Flag 설정
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_SINGLE_TOP| Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // 메세지의 내용을 Extra에 넣어줌
        intent.putExtra("sender", sender);
        intent.putExtra("contents", contents);
        intent.putExtra("receivedDate", receivedDate);

        context.startActivity(intent);
    }

    private SmsMessage[] parseSmsMessage(Bundle bundle){
        Object[] objs = (Object[]) bundle.get("pdus");
        SmsMessage[] messages = new SmsMessage[objs.length];

        for(int i=0; i<objs.length; i++) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                String format = bundle.getString("format");
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i], format);
            } else {
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i]);
            }
        }

        return messages;
    }
}
