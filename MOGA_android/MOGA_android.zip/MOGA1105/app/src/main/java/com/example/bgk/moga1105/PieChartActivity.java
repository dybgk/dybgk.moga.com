package com.example.bgk.moga1105;

import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import java.text.NumberFormat;

public class PieChartActivity extends AppCompatActivity {

    int[] pieChartValues = {10, 10, 20, 20, 40, 50};  //각 계열(Series)의 값
    public static final String TYPE = "type";

    //각 계열(Series)의 색상
    private static int[] COLORS = new int[]{Color.parseColor("#614190"), Color.parseColor("#b563a6"), Color.parseColor("#dfb2d3"),
            Color.parseColor("#ac7d85"), Color.parseColor("#e5998c"), Color.parseColor("#ece2e3")};
    XYSeries xySeries = new XYSeries("test");

    //각 계열의 타이틀
    String[] mSeriesTitle = new String[] {"현금", "신한", "국민", "우리", "하나", "농협"};
    private CategorySeries mSeries = new CategorySeries("결제 수단");
    private DefaultRenderer mRenderer = new DefaultRenderer();
    private GraphicalView mChartView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        mRenderer.setApplyBackgroundColor(true);
        mRenderer.setBackgroundColor(Color.TRANSPARENT);
        mRenderer.setChartTitle("※ 이번 달 결제수단 별 통계 ※");
        mRenderer.setChartTitleTextSize(70);
        mRenderer.setLabelsTextSize(75);
        mRenderer.setLegendTextSize(75);
//        mRenderer.setMargins(new int[]{20, 30, 15, 0});
        mRenderer.setMargins(new int[]{0, 0, 5, 5});
        mRenderer.setZoomButtonsVisible(true);
        mRenderer.setStartAngle(-90);
        mRenderer.setLabelsColor(Color.BLACK);
        mRenderer.setDisplayValues(true);
//        mRenderer.setFitLegend(true);

//        mRenderer.setDisplayChartValues(true);
//        mRenderer.setChartValuesFormat(NumberFormat.getPercentInstance());
//        mRenderer.setChartValuesTextAlign(Paint.Align.CENTER);

        if (mChartView == null) {
            LinearLayout layout = (LinearLayout) findViewById(R.id.chart_pie);
            mChartView = ChartFactory.getPieChartView(this, mSeries, mRenderer);
            mRenderer.setClickEnabled(true);
            mRenderer.setSelectableBuffer(10);
            layout.addView(mChartView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
        } else {
            mChartView.repaint();
        }
        fillPieChart();
    }

    public void fillPieChart() {
        for (int i = 0; i < pieChartValues.length; i++) {
            mSeries.add(mSeriesTitle[i], pieChartValues[i]);

            //Chart에서 사용할 값, 색깔, 텍스트등을 DefaultRenderer객체에 설정
            SimpleSeriesRenderer renderer = new SimpleSeriesRenderer();
            renderer.setColor(COLORS[(mSeries.getItemCount() - 1) % COLORS.length]);

            mRenderer.addSeriesRenderer(renderer);

            if (mChartView != null)
                mChartView.repaint();

        }

    }

}
