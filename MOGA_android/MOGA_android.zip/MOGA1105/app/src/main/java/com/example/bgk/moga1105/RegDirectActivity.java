package com.example.bgk.moga1105;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;

public class RegDirectActivity extends Fragment {
    public RegDirectActivity() {
    }

    View regdirect_view;

    Calendar cal;
    int cYear;
    int cMonth;
    int cDay;
    int cHour;
    int cMinute;

    DatePickerDialog date_dialog;
    TimePickerDialog time_dialog;

    TextView direct_date;
    TextView direct_time;

    Spinner direct_payway;
    Spinner direct_payway_month;
    Spinner direct_kind;
    Spinner register_spinner;

    private static final String[] direct_payway_array = {"현금", "신한", "국민", "우리", "하나", "농협"};
    private static final String[] direct_payway_month_array = {"일시불", "1개월", "2개월", "3개월",
            "4개월", "5개월", "6개월", "7개월", "8개월", "9개월", "10개월", "11개월", "12개월",
            "13개월", "14개월", "15개월", "16개월", "17개월", "18개월", "19개월", "20개월", "21개월",
            "22개월", "23개월", "24개월", "그 외"};
    private static final String[] direct_kind_array = {"식비", "문화생활비", "주거생활비", "건강관리비", "교통비", "차량유지비", "쇼핑비", "미용비", "교육비", "사회생활비", "유흥비", "금융보험비", "저축", "기타"};
    private static final String[] register_spinner_array = {"지출", "수입"};

    private ArrayAdapter<String> spinner_adapter1;
    private ArrayAdapter<String> spinner_adapter2;
    private ArrayAdapter<String> spinner_adapter3;
    private ArrayAdapter<String> spinner_adapter4;

    public String d_id;

    Button regdirect_btn;

    EditText direct_where;
    EditText direct_what;
    EditText direct_cost;

//    private String id;
    private String d_year;
    private String d_month;
    private String d_day;
    private String d_hour;
    private String d_minute;
    private String d_where;
    private String d_what;
    private String d_cost;
    private String d_payway;
    private String d_payway_m;

    private String d_kind;
    private String d_type;

    String IP = MyGlobalV.getInstance().getMy_ip();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        regdirect_view = inflater.inflate(R.layout.register_direct, container, false);

        cal = Calendar.getInstance();
        cYear = cal.get(Calendar.YEAR);
        cMonth = cal.get(Calendar.MONTH);
        cDay = cal.get(Calendar.DAY_OF_MONTH);
        cHour = cal.get(Calendar.HOUR_OF_DAY);
        cMinute = cal.get(Calendar.MINUTE);

        date_dialog = new DatePickerDialog(getContext(), android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                date_listener, cYear, cMonth, cDay);
        time_dialog = new TimePickerDialog(getContext(), android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                time_listener, cHour, cMinute, true);

        direct_date = (TextView)regdirect_view.findViewById(R.id.direct_date);
        direct_time = (TextView)regdirect_view.findViewById(R.id.direct_time);

        direct_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                date_dialog.show();

            }
        });

        direct_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                time_dialog.show();

            }
        });

        spinner_adapter1 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, direct_payway_array);
        spinner_adapter1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        direct_payway = (Spinner) regdirect_view.findViewById(R.id.direct_payway);
        direct_payway.setAdapter(spinner_adapter1);
        direct_payway.setSelection(0);

        spinner_adapter2 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, direct_payway_month_array);
        spinner_adapter2.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        direct_payway_month = (Spinner) regdirect_view.findViewById(R.id.direct_payway_month);
        direct_payway_month.setAdapter(spinner_adapter2);
        direct_payway_month.setSelection(0);

        spinner_adapter3 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, direct_kind_array);
        spinner_adapter3.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        direct_kind = (Spinner) regdirect_view.findViewById(R.id.direct_kind);
        direct_kind.setAdapter(spinner_adapter3);
        direct_kind.setSelection(0);

        spinner_adapter4 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, register_spinner_array);
        spinner_adapter4.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        register_spinner = (Spinner) regdirect_view.findViewById(R.id.register_spinner);
        register_spinner.setAdapter(spinner_adapter4);
        register_spinner.setSelection(0);

        // id 받기 open
        Bundle bundle4 = this.getArguments();
        if (bundle4 != null) {
            d_id = bundle4.getString("d_id");
        }
        // close

        direct_where = (EditText)regdirect_view.findViewById(R.id.direct_where);
        direct_what = (EditText)regdirect_view.findViewById(R.id.direct_what);
        direct_cost = (EditText)regdirect_view.findViewById(R.id.direct_cost);

        regdirect_btn = (Button)regdirect_view.findViewById(R.id.regdirect_btn);
        regdirect_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d_kind = direct_kind.getSelectedItem().toString();
                d_where = direct_where.getText().toString();
                d_what = direct_what.getText().toString();
                d_cost = direct_cost.getText().toString();
                d_payway = direct_payway.getSelectedItem().toString();
                d_payway_m = direct_payway_month.getSelectedItem().toString();

                d_type = "paydirect";

                try {

                    String result  = new RegDirectTask().execute(
                            d_id, d_year, d_month, d_day, d_hour, d_minute,
                            d_where, d_what, d_cost, d_payway, d_payway_m, d_type, d_kind).get();
                    if(result.equals("insert_good")) {
                        Toast.makeText(regdirect_view.getContext(),"가계부에 입력하였습니다.",Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(regdirect_view.getContext(),"가계부에 입력을 실패하였습니다.",Toast.LENGTH_SHORT).show();
                    }

                    Log.d("★☆★ 여기 ★☆★", d_id);
                } catch (Exception e) {

                }
            }
        });

        return regdirect_view;
    }

    class RegDirectTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;
        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaDirect.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(50000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "d_id="+strings[0]+"&d_year="+strings[1]+"&d_month="+strings[2]+"&d_day="+strings[3]
                        +"&d_hour="+strings[4]+"&d_minute="+strings[5]+"&d_where="+strings[6]+"&d_what="+strings[7]
                        +"&d_cost="+strings[8]+"&d_payway="+strings[9]+"&d_payway_m="+strings[10]+"&d_type="+strings[11]+"&d_kind="+strings[12];
                osw.write(sendMsg);
                osw.flush();
                if(conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode()+"에러");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    private DatePickerDialog.OnDateSetListener date_listener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            monthOfYear = monthOfYear + 1;
            direct_date.setText(year + "년 " + monthOfYear + "월 " + dayOfMonth + "일");

            d_year = Integer.toString(year);
            d_month = Integer.toString(monthOfYear);
            d_day = Integer.toString(dayOfMonth);
        }
    };

    private TimePickerDialog.OnTimeSetListener time_listener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            direct_time.setText(hourOfDay + "시 " + minute + "분");

            d_hour = Integer.toString(hourOfDay);
            d_minute = Integer.toString(minute);
        }
    };

}
