package com.example.bgk.moga1105;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    Button join_btn;
    Button login_btn;

    EditText loginmem_id;
    EditText loginmem_pw;

    String l_id = null;
    String l_pw = null;

    String IP = MyGlobalV.getInstance().getMy_ip();

    final long FINISH_INTERVAL_TIME = 2000;
    long   backPressedTime = 0;

    private LinearLayout toastLayout;
    private TextView toastTV;
    private Toast toast;

    public static final int MY_PERMISSIONS_REQUEST_RECEIVE_SMS = 101;
    TextView customTitle;

    SharedPreferences auto;
    SharedPreferences.Editor autoLogin;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getSupportActionBar().setCustomView(R.layout.custom_title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        customTitle = (TextView)findViewById(R.id.customTitle);
        customTitle.setText(R.string.app_name);

        setContentView(R.layout.activity_main);

        loginmem_id = (EditText)findViewById(R.id.loginmem_id);
        loginmem_pw = (EditText)findViewById(R.id.loginmem_pw);

        join_btn = (Button)findViewById(R.id.join_btn);
        login_btn = (Button)findViewById(R.id.login_btn);
        auto = getSharedPreferences("auto", 0);
        //로그인 성공한 아이디와 비번을 SharedPreferences.Editor를 통해
        //auto의 loginId와 loginPwd에 값을 저장해 줍니다.
        autoLogin = auto.edit();

        join_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent to_join = new Intent(MainActivity.this, RegMemberActivity.class);
                startActivity(to_join);
                finish();
            }
        });

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                l_id = loginmem_id.getText().toString();
                l_pw = loginmem_pw.getText().toString();

                try {
                    String result  = new LoginMemTask().execute(l_id, l_pw, "memberlogin").get();
                    if(result.equals("true")) {
                        Toast.makeText(getApplicationContext(),l_id + " 님, 환영합니다.",Toast.LENGTH_SHORT).show();
//                        SharedPreferences auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
//                        //로그인 성공한 아이디와 비번을 SharedPreferences.Editor를 통해
//                        //auto의 loginId와 loginPwd에 값을 저장해 줍니다.
//                        SharedPreferences.Editor autoLogin = auto.edit();
                        autoLogin.putString("inputId", l_id);
                        autoLogin.putString("inputPwd", l_pw);
                        autoLogin.putBoolean("Auto_Login_enabled", true);
                        //꼭 commit()을 해줘야 값이 저장됩니다 ㅎㅎ
                        autoLogin.commit();

                        Intent to_tab = new Intent(MainActivity.this, TabActivity.class);
                        to_tab.putExtra("m_id", l_id);
                        startActivity(to_tab);
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(),"로그인을 실패하였습니다.",Toast.LENGTH_SHORT).show();
                    }

                    Log.d("★☆★ 여기 ★☆★", l_id+"/"+l_pw+"/"+"memberlogin");

                } catch (Exception e) {

                }

                Log.d("★☆★ 여기 ★☆★", l_id+"/"+l_pw+"/"+"memberlogin");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {

        } else {
            makeRequest(Manifest.permission.RECEIVE_SMS);
        }
    }

    private int checkPermission(String permission) {
        return ContextCompat.checkSelfPermission(this, permission);
    }

    private void makeRequest(String permission) {
        ActivityCompat.requestPermissions(this, new String[]{permission}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_REQUEST_RECEIVE_SMS) {
            if (grantResults.length == 0 && grantResults[0] == PackageManager.PERMISSION_DENIED
                    && grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(getApplicationContext(),"이 응용프로그램을 실행하시려면 문자 읽기 권한을 허용하셔야 합니다.", Toast.LENGTH_SHORT).show();
                finish();
            } else {

            }
        }
    }

    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if (0 <= intervalTime && FINISH_INTERVAL_TIME >= intervalTime)
        {
            super.onBackPressed();
        }
        else
        {
            backPressedTime = tempTime;
            toast=Toast.makeText(getApplicationContext(), "앱을 종료하려면,\n뒤로가기 버튼을 한번 더 눌러주세요.", Toast.LENGTH_SHORT);
            toastLayout = (LinearLayout)toast.getView();
            toastTV = (TextView)toastLayout.getChildAt(0);
            toast.show();
        }
    }

    class LoginMemTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;
        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaMember.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(50000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "m_id="+strings[0]+"&m_pw="+strings[1]+"&type="+strings[2];
                osw.write(sendMsg);
                osw.flush();
                if(conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode()+"에러");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }
}
