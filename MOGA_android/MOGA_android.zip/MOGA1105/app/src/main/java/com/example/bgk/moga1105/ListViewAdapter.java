package com.example.bgk.moga1105;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

// listview adapter for pay & income listview
public class ListViewAdapter extends BaseAdapter {

    public ArrayList<ListViewItem> listViewItemList = new ArrayList<ListViewItem>();

    public ListViewAdapter() {

    }

    @Override
    public int getCount() {
        return listViewItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Context context = parent.getContext();

        if(convertView == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listview_row, parent, false);
        }

        TextView date_list = (TextView)convertView.findViewById(R.id.date_list);
        TextView day_sum_list = (TextView)convertView.findViewById(R.id.day_sum_list);
        TextView time_list = (TextView)convertView.findViewById(R.id.time_list);
        TextView payway_list = (TextView)convertView.findViewById(R.id.payway_list);
        TextView payway_m_list = (TextView)convertView.findViewById(R.id.payway_m_list);
        TextView where_list = (TextView)convertView.findViewById(R.id.where_list);
        TextView what_list = (TextView)convertView.findViewById(R.id.what_list);
        TextView cost_list = (TextView)convertView.findViewById(R.id.cost_list);

        ListViewItem listviewItem = (listViewItemList).get(position);

        date_list.setText(listviewItem.getDate_list());
//        day_sum_list.setText(listviewItem.getDay_sum_list());
        time_list.setText(listviewItem.getTime_list());
        payway_list.setText(listviewItem.getPayway_list());
//        payway_m_list.setText(listviewItem.getPayway_m_list());
        payway_m_list.setText(listviewItem.getCategory_list());
        where_list.setText(listviewItem.getWhere_list());
        what_list.setText(listviewItem.getWhat_list());
        cost_list.setText(listviewItem.getCost_list());

        return convertView;
    }

    //day_sum 일단 제외
    public void addItem(String date, String time, String payway, String payway_m,
                        String where, String what, String cost, String category) {
        ListViewItem item = new ListViewItem();

        item.setDate_list(date);
        item.setTime_list(time);
        item.setPayway_list(payway);
        item.setPayway_m_list(payway_m);
        item.setWhere_list(where);
        item.setWhat_list(what);
        item.setCost_list(cost);
        item.setCategory_list(category);

        listViewItemList.add(item);
    }

}
