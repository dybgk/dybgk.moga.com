package com.example.bgk.moga1105;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Currency;
import java.util.Locale;

public class SmsTestActivity extends AppCompatActivity {
    String IP = MyGlobalV.getInstance().getMy_ip();

    final long FINISH_INTERVAL_TIME = 2000;
    long   backPressedTime = 0;

    private LinearLayout toastLayout;
    private TextView toastTV;
    private Toast toast;

    public static final int MY_PERMISSIONS_REQUEST_RECEIVE_SMS = 101;

    String t_sender = "";
    String t_message = "";
    String t_receivedDate = "";
    String t_where = "";
    String t_won = "";
    String t_card = "";

    TextView test_sender;
    TextView test_card;
    TextView test_contents;
    TextView test_receivedDate;

    Spinner test_category;
    //아래 항목들은 똑똑가계부 참조.
    private static final String[] test_category_array = {"식비", "문화생활비", "주거생활비", "건강관리비", "교통비", "차량유지비", "쇼핑비", "미용비", "교육비", "사회생활비", "유흥비", "금융보험비", "저축", "기타"};
    private ArrayAdapter<String> spinner_adapter_category;
    String test_category_s;

    JSONObject result_json = null;
    int list_cnt;
    String indsLclsNm = "";
    String d_bigcategory = "";
    String won_symbol = Currency.getInstance(Locale.KOREA).getSymbol();

    Button inputOk;
    Button inputNo;

    String sms_id = "poi";
    String t_year = "";
    String t_month = "";
    String t_day = "";
    String t_hour = "";
    String t_minute = "";

    String t_payway = "";
    String t_cost = "";
    String t_what = "";
    String t_payway_m = "";

    String t_kind = "";

    TextView customTitle;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smstest);

        try {
            getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getSupportActionBar().setCustomView(R.layout.custom_title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        customTitle = (TextView)findViewById(R.id.customTitle);
        customTitle.setText(R.string.app_name);

        Log.d("여기는_테스트", "t_card : " + MyGlobalV.getInstance().getG_card());
        Log.d("여기는_테스트", "Sender : " + MyGlobalV.getInstance().getG_sender());
//        Log.d("여기는_테스트", "Contents : " + MyGlobalV.getInstance().getG_message());
        Log.d("여기는_테스트", "t_where : " + MyGlobalV.getInstance().getG_where());
        Log.d("여기는_테스트", "t_won : " + MyGlobalV.getInstance().getG_won());
        Log.d("여기는_테스트", "receivedDate : " + MyGlobalV.getInstance().getG_receivedDate());

        t_card = MyGlobalV.getInstance().getG_card();
        t_sender = MyGlobalV.getInstance().getG_sender();
//        t_message = MyGlobalV.getInstance().getG_message();
        t_where = MyGlobalV.getInstance().getG_where();
        t_won = MyGlobalV.getInstance().getG_won();
        t_receivedDate = MyGlobalV.getInstance().getG_receivedDate();

        test_sender = (TextView)findViewById(R.id.test_sender);
        test_card = (TextView)findViewById(R.id.test_card);
        test_contents = (TextView)findViewById(R.id.test_contents);
        test_receivedDate = (TextView)findViewById(R.id.test_receivedDate);

        spinner_adapter_category = new ArrayAdapter<String>(
                getApplicationContext(),
                R.layout.spinner_layout,
                test_category_array);
        spinner_adapter_category.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        test_category = (Spinner)findViewById(R.id.test_category);
        test_category.setAdapter(spinner_adapter_category);

        if(t_where.contains("커피")
                ||t_where.contains("식당") == true) {
            d_bigcategory = "식비";
        } else if(t_where.contains("약국")
                ||t_where.contains("병원")
                ||t_where.contains("의원")
                == true) {
            d_bigcategory = "건강관리비";
        } else if(t_where.contains("교통") == true) {
            d_bigcategory = "교통비";
        } else if(t_where.contains("학원") == true) {
            d_bigcategory = "교육비";
        } else {
            try {
                String result;
                StorelistTask task = new StorelistTask();
                result = task.execute(t_where).get();
                Log.i("카테고리 테이블", result);

                result_json = new JSONObject(result);
            } catch (Exception e) {

            }

            StorelistReader();
            Log.d("함수 밖 - 카테고리", d_bigcategory);
        }
        Log.d("카테고리 결정", d_bigcategory);
        test_category.setSelection(spinner_adapter_category.getPosition(d_bigcategory));
        test_category_s = test_category.getSelectedItem().toString();

        test_sender.setText(t_where);
        test_card.setText(t_card);
        if(t_won == null) {
            test_contents.setText("");
        } else {
            test_contents.setText(Currency.getInstance(Locale.KOREA).getSymbol() + " " + t_won);
        }
        test_receivedDate.setText(t_receivedDate);

        t_year = t_receivedDate.substring(0, t_receivedDate.indexOf("년"));
        t_month = t_receivedDate.substring(t_receivedDate.indexOf("년")+1, t_receivedDate.indexOf("월"));
        t_day = t_receivedDate.substring(t_receivedDate.indexOf("월")+1, t_receivedDate.indexOf("일"));
        t_hour = t_receivedDate.substring(t_receivedDate.indexOf("일 ")+1, t_receivedDate.indexOf(":"));
        t_minute = t_receivedDate.substring(t_receivedDate.indexOf(":")+1);
        t_payway = t_card;
        t_cost = t_won;
        t_kind = test_category_s;

        Log.d("여기는_테스트", "sms_id : " + sms_id);
        Log.d("여기는_테스트", "t_year : " + t_year);
        Log.d("여기는_테스트", "t_month : " + t_month);
        Log.d("여기는_테스트", "t_day : " + t_day);
        Log.d("여기는_테스트", "t_hour : " + t_hour);
        Log.d("여기는_테스트", "t_minute : " + t_minute);
        Log.d("여기는_테스트", "t_payway : " + t_payway);
        Log.d("여기는_테스트", "t_kind : " + t_kind);

        inputOk = (Button)findViewById(R.id.inputOk);
        inputNo = (Button)findViewById(R.id.inputNo);

        inputOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    String result  = new RegSmsTask().execute(
                            sms_id, t_year, t_month, t_day, t_hour, t_minute,
                            t_where, t_what, t_cost, t_payway, t_payway_m, "paydirect", t_kind).get();
                    if(result.equals("insert_good")) {
                        Toast.makeText(getApplicationContext(),"가계부에 입력하였습니다.",Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(),"가계부에 입력을 실패하였습니다.",Toast.LENGTH_SHORT).show();
                    }

                    Log.d("★☆★ 여기 ★☆★", sms_id);
                } catch (Exception e) {

                }

                //입력버튼 누르면 DB에 입력 후 이 액티비티 종료
                finish();
            }
        });

        inputNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //취소 버튼 누르면 폰의 뒤로가기 버튼 누른 것 같은 효과
                onBackPressed();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
        } else {
            makeRequest(Manifest.permission.RECEIVE_SMS);
        }
    }

    private int checkPermission(String permission) {
        return ContextCompat.checkSelfPermission(this, permission);
    }

    private void makeRequest(String permission) {
        ActivityCompat.requestPermissions(this, new String[]{permission}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_REQUEST_RECEIVE_SMS) {
            if (grantResults.length == 0 && grantResults[0] == PackageManager.PERMISSION_DENIED
                    && grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(getApplicationContext(),"이 응용프로그램을 실행하시려면 문자 읽기 권한을 허용하셔야 합니다.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
            }
        }
    }

    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if (0 <= intervalTime && FINISH_INTERVAL_TIME >= intervalTime)
        {
            super.onBackPressed();
        }
        else
        {
            backPressedTime = tempTime;
            toast=Toast.makeText(getApplicationContext(), "이 페이지에서 나가시려면,\n뒤로가기 버튼을 한번 더 눌러주세요.", Toast.LENGTH_SHORT);
            toastLayout = (LinearLayout)toast.getView();
            toastTV = (TextView)toastLayout.getChildAt(0);
            toast.show();
        }
    }

    class RegSmsTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;
        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaDirect.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(50000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "d_id="+strings[0]+"&d_year="+strings[1]+"&d_month="+strings[2]+"&d_day="+strings[3]
                        +"&d_hour="+strings[4]+"&d_minute="+strings[5]+"&d_where="+strings[6]+"&d_what="+strings[7]
                        +"&d_cost="+strings[8]+"&d_payway="+strings[9]+"&d_payway_m="+strings[10]+"&d_type="+strings[11]+"&d_kind="+strings[12];
                osw.write(sendMsg);
                osw.flush();
                if(conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode()+"에러");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    class StorelistTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;
        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaStorelistReader.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(50000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "d_where="+strings[0];
                osw.write(sendMsg);
                osw.flush();
                if(conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "EUC-KR");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode()+"에러");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    private void StorelistReader() {
        try {
            JSONArray jsonArray = result_json.getJSONArray("StorelistData");

            list_cnt = jsonArray.length();
            Log.e("array_count", list_cnt + "");

            indsLclsNm = new String();

            JSONObject jObject = jsonArray.getJSONObject(0);

            Log.e("JSON Object", jObject + "");
            indsLclsNm = jObject.getString("indsLclsNm");

            Log.d("받아온 대분류 : ", indsLclsNm);

            switch(indsLclsNm) {
                case "음식":
                    d_bigcategory = "식비";
                    break;
                case "문화/예술/종교":
                    d_bigcategory = "문화생활비";
                    break;
                case "부동산":
                case "숙박":
                case "전기/가스/수도":
                case "전자/정보통신":
                    d_bigcategory = "주거생활비";
                    break;
                case "스포츠":
                case "의료":
                    d_bigcategory = "건강관리비";
                    break;
                case "교통/운송":
                    d_bigcategory = "차량유지비";
                    break;
                case "소매":
                    d_bigcategory = "쇼핑비";
                    break;
                case "생활서비스":
                    d_bigcategory = "미용비";
                    break;
                case "학문/교육":
                    d_bigcategory = "교육비";
                    break;
                case "관광/여가/오락":
                    d_bigcategory = "유흥비";
                    break;
                case "금융":
                    d_bigcategory = "금융보험비";
                    break;
                case "1차산업":
                case "국가기관/단체":
                case "기술/건축/환경":
                case "도매/유통/무역":
                case "복지":
                case "업종분류불능":
                case "언론/미디어":
                case "제조":
                    d_bigcategory = "기타";
                    break;
                default:
                    d_bigcategory = "식비";
            }
            Log.d("함수 안 - 카테고리", d_bigcategory);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
