package com.example.bgk.moga1105;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Locale;

// 지금은 사용하지 않음.
public class IncomeActivity extends Fragment {
    public IncomeActivity() {
    }

    View income_view;

    String IP = MyGlobalV.getInstance().getMy_ip();

    ListView income_listview;
    ListViewAdapter listviewAdapter;
    ListViewItem listItem;
    ArrayList<ListViewItem> listviewItemList = new ArrayList<ListViewItem>();

    int list_cnt;
    String[] i_years;
    String[] i_months;
    String[] i_days;
    String[] i_hours;
    String[] i_minutes;
    String[] i_wheres;
    String[] i_whats;
    String[] i_costs;
    String[] i_payways;
    String[] i_payway_ms;
    String i_date;
    String i_time;
    String i_won;

    String i_id;
    String result;

    JSONObject result_json = null;

    Spinner income_year_choice;
    Spinner income_month_choice;

    private static final String[] income_year_choice_array = {"2011", "2012", "2013", "2014",
            "2015", "2016", "2017", "2018"};
    private static final String[] income_month_choice_array = {"1", "2", "3", "4", "5", "6",
            "7", "8", "9", "10", "11", "12"};

    private ArrayAdapter<String> spinner_adapter1;
    private ArrayAdapter<String> spinner_adapter2;

    String income_year_choice_s;
    String income_month_choice_s;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        income_view = inflater.inflate(R.layout.activity_income, container, false);

        spinner_adapter1 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, income_year_choice_array);
        spinner_adapter1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        income_year_choice = (Spinner) income_view.findViewById(R.id.income_year_choice);
        income_year_choice.setAdapter(spinner_adapter1);
        income_year_choice.setSelection(7);

        spinner_adapter2 = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_item, income_month_choice_array);
        spinner_adapter2.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        income_month_choice = (Spinner) income_view.findViewById(R.id.income_month_choice);
        income_month_choice.setAdapter(spinner_adapter2);
        income_month_choice.setSelection(5);

        // id 받기 open
        Bundle bundle2 = this.getArguments();
        if (bundle2 != null) {
            i_id = bundle2.getString("i_id");
        }
        Log.d("인컴 아이디", i_id);
        // close

        income_month_choice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                income_year_choice_s = income_year_choice.getSelectedItem().toString();
                income_month_choice_s = income_month_choice.getSelectedItem().toString();

                Log.d("선택 값", income_year_choice_s + "/" + income_month_choice_s);

                try {
                    String result;
                    IncomeTask task = new IncomeTask();
                    result = task.execute(i_id, income_year_choice_s, income_month_choice_s).get();
                    Log.i("수입 내역 테이블", result);

                    result_json = new JSONObject(result);
                } catch (Exception e) {

                }

                income_listview = (ListView) income_view.findViewById(R.id.income_listview);
                listviewAdapter = new ListViewAdapter();
                income_listview.setAdapter(listviewAdapter);

                IncomeReader();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return income_view;
    }

    class IncomeTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;

        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL(IP + "mogaIncomeReader.jsp");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "id=" + strings[0] + "&year=" + strings[1] + "&month=" + strings[2];
                osw.write(sendMsg);
                osw.flush();
                if (conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "EUC-KR");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode() + "에러");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }

    private void IncomeReader() {
        try {
            JSONArray jsonArray = result_json.getJSONArray("IncomeData");

            list_cnt = jsonArray.length();
            Log.e("array_count", list_cnt + "");

            i_years = new String[list_cnt];
            i_months = new String[list_cnt];
            i_days = new String[list_cnt];
            i_hours = new String[list_cnt];
            i_minutes = new String[list_cnt];
            i_wheres = new String[list_cnt];
            i_whats = new String[list_cnt];
            i_costs = new String[list_cnt];
            i_payways = new String[list_cnt];
            i_payway_ms = new String[list_cnt];

            for (int i = 0; i < list_cnt; i++) {
                JSONObject jObject = jsonArray.getJSONObject(i);
                listItem = new ListViewItem();

                Log.e("JSON Object", jObject + "");
                i_years[i] = jObject.getString("i_year");
                i_months[i] = jObject.getString("i_month");
                i_days[i] = jObject.getString("i_day");
                i_hours[i] = jObject.getString("i_hour");
                i_minutes[i] = jObject.getString("i_minute");
                i_wheres[i] = jObject.getString("i_where");
                i_whats[i] = jObject.getString("i_what");
                i_costs[i] = jObject.getString("i_cost");
                i_payways[i] = jObject.getString("i_payway");
                i_payway_ms[i] = jObject.getString("i_payway_m");

                i_date = i_years[i] + " / " + i_months[i] + " / " + i_days[i];
                i_time = i_hours[i] + " : " + i_minutes[i];
                i_won = Currency.getInstance(Locale.KOREA).getSymbol()+ i_costs[i];

                listItem.setDate_list(i_date);
//                                listItem.setDay_sum_list();
                listItem.setTime_list(i_time);
                listItem.setPayway_list(i_payways[i]);
                listItem.setPayway_m_list(i_payway_ms[i]);
                listItem.setWhere_list(i_wheres[i]);
                listItem.setWhat_list(i_whats[i]);
                listItem.setCost_list(i_won);

                listviewItemList.add(listItem);
                listviewAdapter.addItem(i_date, i_time, i_payways[i], i_payway_ms[i]
                        , i_wheres[i], i_whats[i], i_won, "식비");
//                                        listviewAdapter.notifyDataSetChanged();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
